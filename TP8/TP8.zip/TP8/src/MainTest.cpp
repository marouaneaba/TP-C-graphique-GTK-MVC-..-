#define BOOST_TEST_MODULE TestsUnitairesViewerListe
#include <boost/test/included/unit_test.hpp>

#include "Bouteille_test.hpp"
#include "Inventaire_test.hpp"

