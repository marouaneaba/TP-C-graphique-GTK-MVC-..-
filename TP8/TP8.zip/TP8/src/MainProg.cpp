#include "Controleur.hpp"

int main(int argc, char ** argv) {
  Controleur viewer(argc, argv);
  viewer.run();
  return 0;
}
